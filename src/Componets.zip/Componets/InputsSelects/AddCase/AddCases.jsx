import React, { useState } from "react";
import { useSelector } from "react-redux";
import { createCase } from "../../../assets/Controller/llamados";

import { validate } from "./Validate";

import FormAddCase2 from "./FormAddCase2";

function AddCases() {
  let namePeritos1 = useSelector((state) => state.peritosByName);
  let namePeritos=namePeritos1.map(e=>{return {value:e, label:e}})
  // console.log('peritos', namePeritos1)
  
  const [post, setPost] = useState({
    Nombre: "",
    Compañia: "",
    Marca: "",
    Numero: "", //num de denuncia
    Patente: "",
    dia: '',
    mes:'',
    año:'',
    celular: "",
    direccion: "",
    estado: "",
    localidad: "",
    perito: "",
    notas: "",
  });

  const handleChange = (e) => {
    e.preventDefault();
   
    setPost({
      ...post,
      
      [e.target.name]: e.target.value,
    });
  };

  let handleSelect=(value, action)=> {    

   
   
    if (action.name === "day") {
      setPost({
        ...post,
        dia: value.value
      })
    }
    if (action.name === "month") {
      setPost({
        ...post,
        mes: value.value
      })
    }
    if (action.name === "year") {
      setPost({
        ...post,
        año: value.value
      })

      
    }

    
    
    

  
    if (action.name === "localidad") {
      
      setPost({
        ...post,
        localidad: value.value
      })
     
    }
    if (action.name === "peritos") {
     
      setPost({
        ...post,
        perito: value.value
      })
     
    }

      
     
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    let error = await validate(post);
 
    let cases = {
      Nombre: post.Nombre,
      Compañia: post.Compañia,
      Marca: post.Marca,
      Numero: post.Numero, //num de denuncia
      Patente: post.Patente,
      Vencimiento: post.dia + '-' + post.mes + '-' + post.año,
      celular: post.celular,
      direccion: post.direccion,
      estado: post.estado,
      localidad: post.localidad,
      perito: post.perito,
      notas: post.notas,
    };
    if (Object.keys(error).length === 0) {
      try {
        createCase(cases);
      } catch (e) {
        console.log('error de firebase', error)
        alert(e);
      }
    } else {
       let errorA=Object.values(error)
       

      alert(`No se puede guardar el caso presenta el/los siguiente/s error/s:

               ${
                errorA
                 }
                 
        `);
    }
  };
  return (
    <>
    <FormAddCase2 handleChange={handleChange} handleSubmit={handleSubmit} handleSelect={handleSelect} post={post} namePeritos={namePeritos}/>
      
    </>
  );
} 

export default AddCases;
