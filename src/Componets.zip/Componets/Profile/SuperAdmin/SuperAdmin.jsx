import React from 'react'
import { useSelector } from 'react-redux';
import TableCase from '../../Table/TableAdCase/TableCase'
import AddModals from '../../Modals/AddModals'
import AddCases from '../../InputsSelects/AddCase/AddCases'
// import { selectionOptionPeritos } from '../Table/colums2'
// import DataTable2 from '../Table/otherTables/DataTable2'
// import DataTableAll from '../Table/otherTables/DataTableAll'
// import Table3 from '../Table/Table3'

function SuperAdmin() {

  const cases = useSelector(state=>state.cases)
  const peritosByName = useSelector(state=>state.peritosByName)
  
  return (
    <div>SuperAdmin
        {/* <DataTableAll cases={cases} peritos={peritos}/> */}
        {/* <DataTable2 cases={cases} peritos={peritos} /> */}
        <TableCase cases={cases} peritos={peritosByName} />
        <AddModals details={<AddCases/>}/>

    </div>
  )
}

export default SuperAdmin