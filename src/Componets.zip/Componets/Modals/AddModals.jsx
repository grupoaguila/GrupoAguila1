import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import PropTypes from 'prop-types';

function AddModals({details, title, nameBottom,agreeBotton,functionBottonAgree }) {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
    // const handleSubmit=functionBottonAgree()
  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        {/* {nameBottom} */}
        hola
      </Button>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>{title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
         {details}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
         
        </Modal.Footer>
      </Modal>
    </>
  );
}

// render(<AddModals />);
export default AddModals
AddModals.propTypes = {
    children: PropTypes.oneOfType([
      PropTypes.arrayOf(PropTypes.element),
      PropTypes.element.isRequired
    ]),
    details: PropTypes.element,
    title: PropTypes.string.isRequired,
  }
  
  AddModals.defaultProps = {
    details: null,
  }