import React, { useEffect, useState }  from "react";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory, { textFilter } from "react-bootstrap-table2-filter";
// import paginationFactory from "react-bootstrap-table2-paginator";
import {columns, defaultSorted , options} from './colums2'
import car from "../../../assets/car.gif";
// import { Menu, Item, Separator, Submenu, MenuProvider } from "react-contexify";
// import "../node_modules/react-contexify/dist/ReactContexify.min.css";
// import Popup from "reactjs-popup";
// import DatePicker from "react-datepicker";
// import { FaArrowAltCircleRight, FaMap, FaPlusCircle } from "react-icons/fa";
// import "react-datepicker/dist/react-datepicker.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";

function TableCase({cases}) {
  const [loader, setLoader] = useState(false);
console.log('====================================');
console.log(cases);
console.log('====================================');
  useEffect(() => {
    setLoader(true);
    setTimeout(() => {
      setLoader(false);
    }, 3000);
  }, []);

  return (
    
    <div className="App">
       {loader ? (
        <img src={car} alt="Cargando" width="250px" />
      ) : (
        <div>
      <BootstrapTable
        classes="customBootStrapClasses"
        bordered={false}
        bootstrap4={true}
        hover={true}
        keyField="driver"
        data={cases}
        columns={columns}
        defaultSorted={defaultSorted}
        filter={filterFactory()}
        // pagination={paginationFactory()}
      />
      </div>
      )}
    </div>

  )
}

export default TableCase
